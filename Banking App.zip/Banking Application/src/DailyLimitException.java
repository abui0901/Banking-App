//Alexander Bui, Alex Hootsell, Angelo Yu, Justin Kim, Joshua Joseph
public class DailyLimitException extends Exception {

    public DailyLimitException(String message) {
        super(message);
    }
}