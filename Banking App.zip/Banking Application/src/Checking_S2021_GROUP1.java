//Alexander Bui, Alex Hootsell, Angelo Yu, Justin Kim, Joshua Joseph
import java.util.*;
public class Checking_S2021_GROUP1 extends Account_S2021_GROUP1 {
	   double FEE = 1.00;
	   int Count; // Number of transactions this period
	   double bal;
		String accountType;
		String customerID;
		String pw;
		
		public Checking_S2021_GROUP1(String customerID, String accountType,int bal, String pw) {
			this.accountType = accountType;
			this.customerID = customerID;
			this.bal = bal;
			this.pw = pw;
			
		}
		
	  
	  public Checking_S2021_GROUP1() {
	    Count = 0;
	    bal = 100.0;
	  }


	  public Checking_S2021_GROUP1(double initialAmount) {
	    super(initialAmount);
	    Count = 0;
	  }

	  /**
	   * Lets the user withdraw money from the account.
	   * Also lets the user know if they do not have enough money to withdraw.
	 * @throws InsufficientFundsException 
	   */
	  public void withdraw(double amount) throws InsufficientFundsException{
		  if (amount > bal) {
	            throw new InsufficientFundsException(
	                    "You cannot withdraw more than you have!");
		  }
	    bal = bal - amount;
	    Count++;
	    
	  }

	  /**
	   * Lets the user deposit money into their account.
	   * Also sets a limit to the amount of money that can be deposited per day.
	 * @throws DailyLimitException 
	   */
	  public void deposit(double amount) throws DailyLimitException{
		  if (amount > 1000) {
	            throw new DailyLimitException(
	                    "You cannot deposit more than $1000!");
		  }
		  bal = bal + amount;
	    Count++;
	  }

	  /**
	   * Deducts a fee after each transaction.
	 * @throws InsufficientFundsException 
	   */
	  
	  public void deductFees() throws InsufficientFundsException {
	    if (Count > 0) {
	      double fee = FEE * Count;
	      bal = bal - fee;
	    }
	    Count = 0; // Start over because of a new time period.
	  }
	  
	  
	}