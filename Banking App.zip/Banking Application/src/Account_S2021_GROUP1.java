//Alexander Bui, Alex Hootsell, Angelo Yu, Justin Kim, Joshua Joseph
public class Account_S2021_GROUP1 {
   double bal; // Hold the amount in the account

  /** 
   * Default constructor. Creates an account with 100 balance.
   */
  public Account_S2021_GROUP1() {
    bal = 100.00;
  }

  public Account_S2021_GROUP1(double initialAmount) {
    bal = initialAmount;
  }

  /**
   * Lets the user deposit money into their account.
   * Also sets a limit to the amount of money that can be deposited per day.
 * @throws DailyLimitException 
   */
  public void deposit(double amount) throws DailyLimitException {
    bal += amount;
  }

  /**
   * Lets the user withdraw money from the account.
   * Also lets the user know if they do not have enough money to withdraw.
 * @throws InsufficientFundsException 
   */ 
  public void withdraw(double amount) throws InsufficientFundsException {
    bal -= amount;
  }

  /**
   * @return the current balance in the account.
   */
  
  public double getBalance() {
    return bal;
  }

  public String toString() {
    return "Account balance: " + bal;
  }
}