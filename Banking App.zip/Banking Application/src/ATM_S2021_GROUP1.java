//Alexander Bui, Alex Hootsell, Angelo Yu, Justin Kim, Joshua Joseph
import static org.junit.Assert.*;
import java.util.*;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PublicKey;
import java.security.Signature;
import javax.crypto.Cipher;
public class ATM_S2021_GROUP1 {
	
	public String customerName;
    public int customerID = 1;
    private String customerPW;
    public static int count = 1;
    public static String choice;
   
    public ATM_S2021_GROUP1(String user, String password) {
    	
    	this.customerID++;
    	this.customerName = user;
    	this.customerPW = password; 
    	count++;
    	
    }
	
	public static void main(String[] args) throws InsufficientFundsException, DailyLimitException, Exception{
	    
				Scanner kb = new Scanner(System.in);
				
				do {
		        System.out.println("Select a choice:");
		        System.out.println("1. Existing customer");  
		        System.out.println("2. Register");
		        System.out.println("3. Quit");
		        choice = kb.nextLine();
		          //existing user
		         if(choice.equals("1")){

		        	 System.out.println("Enter your username");
		              String Luser = kb.nextLine();
		              System.out.println("Password");
		              String Lpassword = kb.nextLine();
		              double a = count;
		              login(Luser, Lpassword);
		              System.out.println("");
		              choice = kb.nextLine();
		              break;
		          }
		           else if (choice.equals("2")) {
			        	  System.out.println("Choose a name for your account.");
			        	  String user = kb.nextLine();
			        	  System.out.println("Choose a password.");
			        	  String password = kb.next();
			        	  Checking_S2021_GROUP1 count = new Checking_S2021_GROUP1(user, "Savings", 100, password);
			        	  //Creates a Signature object.
					      Signature s = Signature.getInstance("SHA256withRSA");				      
					      //Creates a KeyPair generator object.
					      KeyPairGenerator Kpg = KeyPairGenerator.getInstance("RSA");				      
					      //Initializes the key pair generator.
					      Kpg.initialize(2048);					      
					      //Generates the pair of keys.
					      KeyPair pair = Kpg.generateKeyPair();   					      
					      //Gets the public key from the key pair.
					      PublicKey Pk = pair.getPublic();  
					      //Creates a Cipher object.
					      Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
					      //Initializes a Cipher object.
					      c.init(Cipher.ENCRYPT_MODE, Pk);	  
					      //Adds data to the cipher
					      byte[] input = password.getBytes();	  
					      c.update(input);
					      //encrypts the data.
					      byte[] cipherText = c.doFinal();	 
					      System.out.println( new String(cipherText, "UTF8"));
					      //Initializes the same cipher for decryption.
					      c.init(Cipher.DECRYPT_MODE, pair.getPrivate());				      
					      //Decrypts the text.
					      byte[] decipheredText = c.doFinal(cipherText);
					      System.out.println(new String(decipheredText));
					    
			          }
			          else if(choice.equals("3")){

			              System.out.println("Have a nice day!");
			              break;
			              
			            } 
				} while(true);
            
				
				
			   
				
				
				
				
				
				
				
				
	}
		    public static void login(String Luser, String Lpassword) {
				 Scanner kb = new Scanner(System.in);
				  ArrayList< Checking_S2021_GROUP1> accounts = new ArrayList< Checking_S2021_GROUP1>();

				  	int deposit;
				    int withdraw;
				    double num;
				    
				  
				            System.out.println("Would you like to: ");
				            System.out.println("1. Deposit ");
				            System.out.println("2. Withdraw ");
				            choice = kb.next();
				            if(choice.equals("1")){
				            	/*
				        	     * This code is sensitive as it requires user input, and as a result there is 
				        	     * a risk of an injection attack if the input is not sanitized properly. 
				        	     * */
				        	    do {
				        	    	System.out.println("Please enter the amount that you want to deposit!");
				        	    	while(!kb.hasNextDouble()) {
				        	    		
				        	    		System.out.println("That is not a number!");
				        	    		kb.next();
				        	    		
				        	    		
				        	    	}
				        	    	num = kb.nextDouble();
				        	    	
				        	    	/*
				        	    	 * The following code below helps protect against an injection attack
				        	    	 * by checking user input and ensuring that they cannot enter an invalid input.
				        	    	 * */
				        	    } while(num <= 0);
				        	    
				            }

				            else if (choice.equals("2")){
				            	/*
				        	     * This code is sensitive as it requires user input, and as a result there is 
				        	     * a risk of an injection attack if the input is not sanitized properly. 
				        	     * */
				        	    do {
				        	    	System.out.println("Please enter the amount that you want to withdraw!");
				        	    	while(!kb.hasNextDouble()) {
				        	    		
				        	    		System.out.println("That is not a number!");
				        	    		kb.next();
				        	    		
				        	    		
				        	    	}
				        	    	num = kb.nextDouble();
				        	    	
				        	    	/*
				        	    	 * The following code below helps protect against an injection attack
				        	    	 * by checking user input and ensuring that they cannot enter an invalid input.
				        	    	 * */
				        	    } while(num <= 0);
				        	    

				            }
				            else
				              System.out.println("Invalid");
						}
				          

		
		    
		    
		    
		    

	  /** 
	   * Handles end of month fee deduction for a checking/savings account
	 * @throws InsufficientFundsException 
	 * 
	   */
		    
	  public static void endOfMonth(Savings_S2021_GROUP1 savings) throws InsufficientFundsException {
	    savings.deductFees();
	  }

	  public static void endOfMonth(Checking_S2021_GROUP1 checking) throws InsufficientFundsException {
	    checking.deductFees();
	  }
	  
	  
}
