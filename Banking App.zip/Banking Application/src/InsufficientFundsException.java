//Alexander Bui, Alex Hootsell, Angelo Yu, Justin Kim, Joshua Joseph

public class InsufficientFundsException extends Exception {

    public InsufficientFundsException(String message) {
        super(message);
    }
}