//Alexander Bui, Alex Hootsell, Angelo Yu,Justin Kim, Joshua Joseph
public class Savings_S2021_GROUP1 extends Account_S2021_GROUP1 {
	  double FEE = 1.00;
	  int Count; // Number of transactions this period
	  double bal;

	  
	  public Savings_S2021_GROUP1() {
		  Count = 0;
		  bal = 100.0;
	  }


	  public Savings_S2021_GROUP1(double initialAmount) {
	    super(initialAmount);
	    Count = 0;
	  }

	  /**
	   * Lets the user withdraw money from the account.
	   * Also lets the user know if they do not have enough money to withdraw.
	 * @throws InsufficientFundsException 
	   */
	  public void withdraw(double amount) throws InsufficientFundsException{
		  if (amount > bal) {
	            throw new InsufficientFundsException(
	                    "You cannot withdraw more than you have!");
		  }
	    super.withdraw(amount);
	    Count++;
	    
	  }

	  /**
	   * Lets the user deposit money into their account.
	   * Also sets a limit to the amount of money that can be deposited per day.
	 * @throws DailyLimitException 
	   */
	  public void deposit(double amount) throws DailyLimitException{
		  if (amount > 1000) {
	            throw new DailyLimitException(
	                    "You cannot deposit more than $1000!");
		  }
		  super.deposit(amount);
	    Count++;
	  }

	  /**
	   * Lets the user withdraw money from the account.
	   * Also lets the user know if they do not have enough money to withdraw.
	 * @throws InsufficientFundsException 
	   */
	  public void deductFees() throws InsufficientFundsException {
	    if (Count > 0) {
	      double fee = FEE * Count;
	      super.withdraw(fee);
	    }
	    Count = 0; // Start over because new time period.
	  }
	}